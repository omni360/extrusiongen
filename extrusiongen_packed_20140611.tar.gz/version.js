/**
 * @author Ikaros Kappler
 * @date 2013-10-30
 **/

var VERSION_STRING = "v0.2.26 built 201406006#0";

