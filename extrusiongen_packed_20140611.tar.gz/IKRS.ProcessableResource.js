/**
 * @author Ikaros Kappler
 * @date 2013-10-06
 * @version 1.0.0
 **/

IKRS.ProcessableResource = function() {
    
}