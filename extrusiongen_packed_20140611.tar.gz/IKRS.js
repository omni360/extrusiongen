
/**
 * @author Ikaros Kappler
 * @date 2013-08-13
 * @version 1.0.0
 **/

var IKRS = IKRS || { CREATOR: "Ikaros Kappler",
		     DATE: "2013-08-14"
		   };